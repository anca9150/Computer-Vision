import cv2
import numpy as np
from PIL import Image
import os

DATASET_PATH = "dataset"
TRAIN_FILE = "trainer/trainer.yml"

recognizer = cv2.face.LBPHFaceRecognizer_create()
detector = cv2.CascadeClassifier("haarcascade/haarcascade_frontalface_default.xml")


def get_images_and_labels(path=DATASET_PATH):
    face_samples = []
    ids = []

    for folder_name in os.listdir(path):
        folder_path = os.path.join(path, folder_name)
        if not os.path.isdir(folder_path):
            continue

        for file_name in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file_name)
            img = Image.open(file_path).convert("L")
            img_np = np.array(img, "uint8")

            # Extract NIM sebagai string
            try:
                nim = file_name.split(".")[1]
            except:
                continue

            faces = detector.detectMultiScale(img_np)
            for x, y, w, h in faces:
                face_samples.append(img_np[y : y + h, x : x + w])
                ids.append(nim)

    return face_samples, ids


def train_faces():
    faces, ids = get_images_and_labels()
    if len(faces) == 0:
        print("Dataset kosong. Capture wajah dulu.")
        return False

    # Label harus di-convert ke integer untuk LBPH, simpan mapping NIM -> label
    unique_nims = list(sorted(set(ids)))
    nim_to_label = {nim: idx for idx, nim in enumerate(unique_nims)}
    label_to_nim = {idx: nim for nim, idx in nim_to_label.items()}

    labels = [nim_to_label[nim] for nim in ids]

    recognizer.train(faces, np.array(labels))
    os.makedirs("trainer", exist_ok=True)
    recognizer.write(TRAIN_FILE)
    # Simpan mapping NIM
    np.save("trainer/label_to_nim.npy", label_to_nim)
    print(f"Training selesai! Total wajah: {len(faces)}")
    return True


if __name__ == "__main__":
    train_faces()
