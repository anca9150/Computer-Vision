# Project Presensi Computer Vision

Ini adalah folder untuk project presensi berbasis face detection dan face recognition.
File dan kode akan ditambahkan di sini.
